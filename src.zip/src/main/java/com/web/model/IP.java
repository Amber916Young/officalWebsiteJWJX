package com.web.model;

import lombok.Data;

@Data
public class IP {
    private String regNO;
    private String networkIP;
    private String companyName;
}
