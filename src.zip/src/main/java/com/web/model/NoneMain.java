package com.web.model;

import lombok.Data;

@Data
public class NoneMain {
    int id;
    String tabName;
    int intvalue;
    String strvalue;
    String remark;
    Double booleanValue;
    String floatvalue;
}
