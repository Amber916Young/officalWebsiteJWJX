package com.web.model;

import lombok.Data;

@Data
public class Role {
    private int id;
    private String rolename;
    private String limits;
    private String descr;
    private String check;


}
