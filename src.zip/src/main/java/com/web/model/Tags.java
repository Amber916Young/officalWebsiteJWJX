package com.web.model;

import lombok.Data;

@Data
public class Tags {
    private int id;
    private String tags;
    private String value;
}
