package com.web.utils.wx;

import lombok.Data;

@Data
public class KKTransInfo {
    private String  KfAccount;
}
