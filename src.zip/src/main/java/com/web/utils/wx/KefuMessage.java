package com.web.utils.wx;

import lombok.Data;

@Data
public class KefuMessage extends BaseMessage {
    private KKTransInfo  TransInfo;
}
